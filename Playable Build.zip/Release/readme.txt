SDL Project
===========
SDL.dll


SDL_gfx Project
===============
SDL_gfx.dll


SDL_image Project
=================
SDL_image.dll
jpeg.dll
libpng12-0.dll
libtiff-3.dll
zlib1.dll


SDL_mixer Project
=================
SDL_mixer.h
libogg-0.dll
libvorbis-0.dll
libvorbisfile-3.dll
smpeg.dll


SDL_net Project
===============
SDL_net.dll


SDL_ttf Project
===============
SDL_ttf.h
libfreetype-6.dll

Additional File in This Directory
=================================
Arial.TTF - a sample TTF font



